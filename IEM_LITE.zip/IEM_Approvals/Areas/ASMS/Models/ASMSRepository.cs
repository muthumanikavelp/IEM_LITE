﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IEM_Approvals.Areas.ASMS.Models
{
    public class ASMSRepository
    {
    }
}