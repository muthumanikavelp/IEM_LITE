﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IEM_LITE.BAL;

namespace IEMLITE.Common1
{
    public class Class1
    {
        LoginModule sdf = new LoginModule();
        
    }
}
